import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
    const response = NextResponse.json({ success: true })
    // Elimina cookie con el token de autenticación
    response.cookies.set('auth-token', '', { path: '/', maxAge: 0 })  
    return response
}